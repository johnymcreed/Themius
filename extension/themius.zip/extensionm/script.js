// Create Style
function create()
{
    var style = document.createElement('style');
    style.id = 'themius-css';
    document.body.appendChild(style);

    var script = document.createElement('script');
    script.id = 'themius-js';
    document.body.appendChild(script);
}

// Add Style
function add()
{
    fetch('https://raw.githubusercontent.com/johnymcreed/Themius/Default/themius.v3.css')
     .then(response => response.text())
     .then(text => $('#themius-css').html(text))

    fetch('https://raw.githubusercontent.com/johnymcreed/Themius/Default/themius.v3.js')
     .then(response => response.text())
     .then(text => $('#themius-js').html(text))
}

create()
add();